let scoreGlobal1 = document.getElementById("content-player1");
let scoreGlobal2 = document.getElementById("content-player2");
let score1 = document.getElementById("score1");
let score2 = document.getElementById("score2");
let scoreG1 = 0;
let scoreG2 = 0;
let pts1 = 0;
let pts2 = 0;
let joueur = "player1";
let playeur1 = document.getElementById("player1");
let playeur2 = document.getElementById("player2");
let result = 0;
const modalContainer = document.querySelector(".modal-container");
const modalTriggers = document.querySelectorAll(".modal-trigger");

window.onload = Init;

function reset() {
  let imgD = document.getElementById("imgD");
  imgD.style.display = "block";
  scoreGlobal1.textContent = scoreG1;
  scoreGlobal2.textContent = scoreG2;
  score1.textContent = pts1;
  score2.textContent = pts2;

  if (joueur == "player1") {
    playeur1.style.color = "yellow";
    scoreGlobal1.style.color = "yellow";
    score1.style.color = "yellow";
    pts1 = 0;
    scoreG1 = 0;
    pts2 = 0;
    scoreG2 = 0;
    score1.textContent = pts1;
    scoreGlobal1.textContent = scoreG1;
    score2.textContent = pts2;
    scoreGlobal2.textContent = scoreG2;
  }
}

function plays() {
  let imgD = document.getElementById("imgD");
  let result = 0;
  result = Math.floor(Math.random() * (7 - 1) + 1);
  imgD.src = "img/dice-" + result + ".png";
  if (joueur == "player1") {
    if (result === 1) {
      changePlayer2();
      scoreG1 = 0;
      scoreGlobal1.textContent = scoreG1;
    } else {
      scoreG1 += result;
      scoreGlobal1.textContent = scoreG1;
    }
  } else if (joueur == "player2") {
    if (result === 1) {
      changePlayer1();
      scoreG2 = 0;
      scoreGlobal2.textContent = scoreG2;
    } else {
      scoreG2 += result;
      scoreGlobal2.textContent = scoreG2;
    }
  }
}
function secur() {
  if (joueur === "player1") {
    changePlayer2();
    pts1 += scoreG1;
    score1.textContent = pts1;
    scoreG1 = 0;
    scoreGlobal1.textContent = scoreG1;
    if (pts1 >= 100) {
      alert("le joueur 1 a ganier la partie");
    }
  } else if ((joueur = "player2")) {
    changePlayer1();
    pts2 += scoreG2;
    score2.textContent = pts2;
    scoreG2 = 0;
    scoreGlobal2.textContent = scoreG2;
    if (pts2 >= 100) {
      alert("le joueur 2 a ganier la partie");
    }
  }
}
function changePlayer2() {
  joueur = "player2";
  playeur2.style.color = "yellow";
  scoreGlobal2.style.color = "yellow";
  score2.style.color = "yellow";
  playeur1.style.color = "black";
  scoreGlobal1.style.color = "black";
  score1.style.color = "black";
}
function changePlayer1() {
  joueur = "player1";
  playeur1.style.color = "yellow";
  scoreGlobal1.style.color = "yellow";
  score1.style.color = "yellow";
  playeur2.style.color = "black";
  scoreGlobal2.style.color = "black";
  score2.style.color = "black";
}

function toggleModal() {
  modalContainer.classList.toggle("active");
}

function Init() {
  let restart = document.getElementById("btn3");
  restart.addEventListener("click", reset);
  let lancer = document.getElementById("btn1");
  lancer.addEventListener("click", plays);
  let sauvegarde = document.getElementById("btn2");
  sauvegarde.addEventListener("click", secur);
  modalTriggers.forEach((trigger) =>
    trigger.addEventListener("click", toggleModal)
  );
}
